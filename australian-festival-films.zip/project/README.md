# 🎬 Australian Films at International Festivals

A weekly-updated website tracking Australian films screening at major international film festivals.

## Data Sources
- **TMDB** — metadata, posters, ratings, cast & crew
- **IMDb** — ratings and IDs
- **Letterboxd** — community ratings
- **Screen Australia** — official Australian production data

## Festivals Tracked
Cannes · Venice · Berlin (Berlinale) · Sundance · Toronto (TIFF) · Rotterdam (IFFR) · Tribeca · SXSW

---

## 🚀 Setup

### 1. Get a TMDB API Key (free)
1. Create an account at https://www.themoviedb.org/
2. Go to Settings → API → Request an API key
3. Copy your **API Key (v3 auth)**

### 2. Add the key to GitHub Secrets
1. Go to your GitHub repo → Settings → Secrets and variables → Actions
2. Click **New repository secret**
3. Name: `TMDB_API_KEY`, Value: your key from above

### 3. Deploy the website
The `website/` folder is a static site — deploy it anywhere:

**Netlify (recommended, free):**
1. Push this repo to GitHub
2. Go to https://netlify.com → Add new site → Import from Git
3. Set **Publish directory** to `website`
4. Deploy ✓

**GitHub Pages:**
1. Go to repo Settings → Pages
2. Source: Deploy from a branch → `main` → `/website`

### 4. Enable the weekly scraper
The GitHub Actions workflow (`.github/workflows/scrape.yml`) runs every Monday at 2am UTC.
- It will automatically update `website/data/films.json` and commit the changes
- Netlify/GitHub Pages will auto-redeploy when the data file changes

To run the scraper manually: go to Actions → Weekly Film Scraper → Run workflow

---

## 🖥 Running Locally

```bash
cd scraper
pip install -r requirements.txt
export TMDB_API_KEY="your_key_here"
python scrape.py

# Serve the website
cd ../website
python -m http.server 8000
# Open http://localhost:8000
```

---

## 📁 Project Structure

```
├── scraper/
│   ├── scrape.py          # Main scraper script
│   └── requirements.txt   # Python dependencies
├── website/
│   ├── index.html         # The website
│   └── data/
│       └── films.json     # Film data (updated weekly by scraper)
└── .github/
    └── workflows/
        └── scrape.yml     # Weekly automation
```

---

## 🔧 Customisation

**Add a new festival:** Edit the `FESTIVALS` list in `scraper/scrape.py`

**Change scrape frequency:** Edit the cron expression in `.github/workflows/scrape.yml`
- Daily: `0 2 * * *`
- Weekly (Monday): `0 2 * * 1`
- Fortnightly: `0 2 * * 1/2`

**Update the website design:** Edit `website/index.html` — it's a single self-contained file
